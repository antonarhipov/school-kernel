package org.schoolkernel.workspace;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.FileStore;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.attribute.PosixFilePermission;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.EnumSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import tools.jackson.core.JacksonException;
import tools.jackson.databind.JsonNode;
import tools.jackson.databind.ObjectMapper;
import tools.jackson.databind.json.JsonMapper;

@Component
public class KernelVerifier {
    private static final Logger LOG = LoggerFactory.getLogger(KernelVerifier.class);
    private static final int OUTPUT_LIMIT = 64 * 1024;
    private static final ObjectMapper JSON = JsonMapper.builder().build();
    private final String executable;
    private final KernelProcessLauncher processes;
    private final Path temporaryRoot;

    @Autowired
    public KernelVerifier(
            @Value("${workspace.kernel-executable}") String executable,
            KernelProcessLauncher processes) {
        this(executable, processes, Path.of(System.getProperty("java.io.tmpdir")));
    }

    KernelVerifier(String executable, KernelProcessLauncher processes, Path temporaryRoot) {
        this.executable = resolveExecutable(executable);
        this.processes = processes;
        this.temporaryRoot = temporaryRoot;
    }

    static String resolveExecutable(String executable) {
        if (executable == null || executable.isBlank()) {
            return executable;
        }
        Path path = Path.of(executable);
        if (Files.exists(path)) {
            return path.toAbsolutePath().normalize().toString();
        }
        Path parentRelative = Path.of("..").resolve(executable);
        if (Files.exists(parentRelative)) {
            return parentRelative.toAbsolutePath().normalize().toString();
        }
        return executable;
    }

    public Verification verify(ImportDocuments documents) {
        return verify(documents, Duration.ofSeconds(30), ignored -> {});
    }

    Verification verify(ImportDocuments documents, Duration timeout, java.util.function.Consumer<java.time.Instant> onStart) {
        return verify(documents, timeout, onStart, () -> {});
    }

    Verification verify(ImportDocuments documents, Duration timeout, java.util.function.Consumer<java.time.Instant> onStart, Runnable onStop) {
        JsonNode evidence = execute(documents, timeout, onStart, onStop, false);
        return trusted(evidence, documents, evidence.path("correlationId").asString());
    }

    JsonNode review(ImportDocuments documents, Duration timeout, java.util.function.Consumer<java.time.Instant> onStart, Runnable onStop) {
        return execute(documents, timeout, onStart, onStop, true);
    }

    private JsonNode execute(ImportDocuments documents, Duration timeout, java.util.function.Consumer<java.time.Instant> onStart, Runnable onStop, boolean review) {
        String correlationId = UUID.randomUUID().toString();
        long started = System.nanoTime();
        Path directory = null;
        boolean logged = false;
        Process process = null;
        try {
            directory = Files.createTempDirectory(temporaryRoot, "school-workspace-verify-");
            restrict(directory, true);
            Path definition = directory.resolve("school-definition.json");
            Path output = directory.resolve("verification-result.json");
            writePrivate(definition, CanonicalJson.bytes(documents.definition()));
            List<String> arguments = new ArrayList<>(List.of(
                    executable,
                    review ? "review" : "verify",
                    "--definition", definition.toString(),
                    "--output", output.toString(),
                    "--correlation-id", correlationId));
            if (documents.mode() == ImportDocuments.ImportMode.SUCCESSOR_DEFINITION) arguments.add("--successor");
            if (documents.result() != null) {
                Path result = directory.resolve("timetable-result.json");
                writePrivate(result, CanonicalJson.bytes(review ? documents.result().path("timetable").path("assignments") : documents.result()));
                arguments.add(4, review ? "--assignments" : "--result");
                arguments.add(5, result.toString());
            }
            java.time.Instant beforeStart = java.time.Instant.now();
            process = processes.start(List.copyOf(arguments));
            onStart.accept(beforeStart);
            Process launched = process;
            Thread stdout = Thread.ofVirtual().start(() -> drain(launched.getInputStream()));
            Thread stderr = Thread.ofVirtual().start(() -> drain(launched.getErrorStream()));
            boolean completed = process.waitFor(timeout.toMillis(), TimeUnit.MILLISECONDS);
            if (!completed) {
                throw unavailable("Kernel verification did not finish in time.");
            }
            onStop.run();
            stdout.join(1000);
            stderr.join(1000);
            int exit = process.exitValue();
            JsonNode verification = readVerification(output);
            if (review && (exit == 0 && "REVIEWED".equals(verification.path("status").asString())
                    || exit == 2 && "INVALID_INPUT".equals(verification.path("status").asString()))) {
                if (!correlationId.equals(verification.path("correlationId").asString())) throw unavailable("Mismatched review evidence.");
                if (exit == 0 && (!verification.path("valid").isBoolean() || !verification.path("conflicts").isArray()
                        || !verification.path("hardMatchCounts").isObject() || !verification.path("softMatchCounts").isObject()
                        || verification.path("hardMatchCounts").size() != 19 || verification.path("softMatchCounts").size() != 7
                        || verification.path("hardMatchCounts").properties().stream().anyMatch(e -> !e.getValue().isIntegralNumber() || e.getValue().asLong() < 0)
                        || !verification.path("truncated").isBoolean()
                        || !documents.definition().path("schoolId").equals(verification.path("schoolId"))
                        || verification.path("valid").asBoolean() && (!verification.path("conflicts").isEmpty()
                          || !verification.path("result").path("inputRevision").equals(verification.path("definitionRevision"))
                          || verification.path("hardMatchCounts").properties().stream().anyMatch(e -> e.getValue().asLong(-1) != 0))))
                    throw unavailable("Incomplete review evidence.");
                if (exit == 2 && (!verification.path("validationReport").path("errors").isArray()
                        || verification.path("validationReport").path("errors").isEmpty()
                        || !verification.path("validationReport").path("truncated").isBoolean()))
                    throw unavailable("Review returned no usable located diagnostics.");
                log(correlationId, "REVIEWED", started); logged = true; return verification;
            }
            if (exit == 0 && "VERIFIED".equals(verification.path("status").stringValue())) {
                trusted(verification, documents, correlationId);
                log(correlationId, "VERIFIED", started);
                logged = true;
                return verification;
            }
            if (exit == 2 && "INVALID_INPUT".equals(verification.path("status").stringValue())) {
                log(correlationId, "INVALID_INPUT", started);
                logged = true;
                throw new WorkspaceProblem(
                        HttpStatus.UNPROCESSABLE_ENTITY,
                        "KERNEL_VERIFICATION_FAILED",
                        safeValidationMessage(verification));
            }
            log(correlationId, exitClass(exit), started);
            logged = true;
            throw unavailable("School Kernel could not verify the import.");
        } catch (WorkspaceProblem problem) {
            if (!logged) {
                log(correlationId, "TRANSPORT", started);
            }
            throw problem;
        } catch (IOException exception) {
            log(correlationId, "TRANSPORT", started);
            throw unavailable("School Kernel could not be started.");
        } catch (InterruptedException exception) {
            Thread.currentThread().interrupt();
            log(correlationId, "INTERRUPTED", started);
            throw unavailable("School Kernel verification was interrupted.");
        } finally {
            if (process != null) {
                // Also stop children and reap on interruption. Never settle a live process as completed.
                boolean interrupted = Thread.interrupted();
                if (process.isAlive()) {
                    process.descendants().forEach(ProcessHandle::destroy);
                    process.destroy();
                    try {
                        if (!process.waitFor(2, TimeUnit.SECONDS)) {
                            process.descendants().forEach(ProcessHandle::destroyForcibly);
                            process.destroyForcibly();
                            process.waitFor();
                        }
                    } catch (InterruptedException exception) {
                        interrupted = true;
                        process.destroyForcibly();
                        process.onExit().join();
                    }
                }
                try { process.getInputStream().close(); process.getErrorStream().close(); } catch (IOException ignored) {}
                if (interrupted) Thread.currentThread().interrupt();
            }
            onStop.run();
            deleteTree(directory);
        }
    }

    private static Verification trusted(JsonNode output, ImportDocuments documents, String correlationId) {
        String mode = output.path("mode").stringValue();
        String expectedMode = documents.mode().name();
        String schoolId = output.path("schoolId").stringValue();
        String definitionRevision = output.path("definitionRevision").stringValue();
        if (!correlationId.equals(output.path("correlationId").asString(""))
                || !output.path("kernelVersion").isTextual() || output.path("kernelVersion").asString().isBlank()
                || !output.path("elapsedTimeMs").isIntegralNumber() || output.path("elapsedTimeMs").longValue()<0
                || !expectedMode.equals(mode)
                || schoolId == null
                || !schoolId.equals(documents.definition().path("schoolId").stringValue())
                || definitionRevision == null || !definitionRevision.matches("sha256:[0-9a-f]{64}")
                || output.path("catalogVersion").intValue()
                        != documents.definition().path("catalogVersion").intValue()
                || output.path("schemaVersion").intValue() != 1) {
            throw unavailable("School Kernel returned mismatched verification evidence.");
        }
        if (documents.mode() == ImportDocuments.ImportMode.SUCCESSOR_DEFINITION
                && !output.path("basedOnRevision").equals(documents.definition().path("basedOnRevision")))
            throw unavailable("School Kernel returned mismatched successor lineage evidence.");
        String timetableRevision = null;
        if (documents.mode() == ImportDocuments.ImportMode.ACCEPTED_BASELINE) {
            timetableRevision = output.path("timetableRevision").stringValue();
            if (timetableRevision == null || !timetableRevision.matches("sha256:[0-9a-f]{64}")
                    || !definitionRevision.equals(documents.result().path("inputRevision").stringValue())
                    || !timetableRevision.equals(documents.result().path("timetableRevision").stringValue())) {
                throw unavailable("School Kernel returned mismatched baseline evidence.");
            }
        }
        return new Verification(schoolId, definitionRevision, timetableRevision);
    }

    private static JsonNode readVerification(Path output) {
        try {
            if (!Files.isRegularFile(output) || Files.size(output) > 2 * 1024 * 1024) {
                throw unavailable("School Kernel did not publish bounded verification evidence.");
            }
            return JSON.readTree(Files.readAllBytes(output));
        } catch (JacksonException exception) {
            throw unavailable("School Kernel published malformed verification evidence.");
        } catch (IOException exception) {
            throw unavailable("School Kernel verification evidence could not be read.");
        }
    }

    private static String safeValidationMessage(JsonNode verification) {
        JsonNode report = verification.path("validationReport"), errors = report.path("errors");
        if (!errors.isArray() || errors.isEmpty() || !report.path("truncated").isBoolean()
                || report.path("truncated").booleanValue() || !report.path("totalErrors").isIntegralNumber()
                || report.path("totalErrors").intValue() != errors.size()) {
            throw unavailable("Kernel verification did not return a complete diagnostic report.");
        }
        StringBuilder message = new StringBuilder("Definition verification failed:");
        for (JsonNode error : errors) {
            if (!error.path("message").isTextual() || error.path("message").asString().isBlank()
                    || !error.path("location").isTextual() || !error.path("entityIds").isArray()) {
                throw unavailable("Kernel verification returned unmappable diagnostics.");
            }
            message.append("\n").append(error.path("location").asString().isEmpty() ? "/" : error.path("location").asString())
                    .append(": ").append(error.path("message").asString());
            if (!error.path("entityIds").isEmpty()) message.append(" • ").append(error.path("entityIds"));
        }
        return message.toString();
    }

    private static void writePrivate(Path path, byte[] bytes) throws IOException {
        Files.write(path, bytes);
        restrict(path, false);
    }

    private static void restrict(Path path, boolean directory) throws IOException {
        FileStore store = Files.getFileStore(path);
        if (store.supportsFileAttributeView("posix")) {
            Set<PosixFilePermission> permissions = directory
                    ? EnumSet.of(PosixFilePermission.OWNER_READ, PosixFilePermission.OWNER_WRITE,
                            PosixFilePermission.OWNER_EXECUTE)
                    : EnumSet.of(PosixFilePermission.OWNER_READ, PosixFilePermission.OWNER_WRITE);
            Files.setPosixFilePermissions(path, permissions);
        }
    }

    private static void drain(InputStream stream) {
        try (stream; ByteArrayOutputStream bounded = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[4096];
            int read;
            int retained = 0;
            while ((read = stream.read(buffer)) >= 0) {
                int keep = Math.min(read, OUTPUT_LIMIT - retained);
                if (keep > 0) {
                    bounded.write(buffer, 0, keep);
                    retained += keep;
                }
            }
        } catch (IOException ignored) {
            // Process outcome and structured file remain authoritative.
        }
    }

    private static String exitClass(int exit) {
        return switch (exit) {
            case 0 -> "VERIFIED";
            case 2 -> "INVALID_INPUT";
            case 4 -> "INTERNAL_ERROR";
            default -> "TRANSPORT";
        };
    }

    private static void log(String correlationId, String exitClass, long started) {
        LOG.info("correlationId={} kernelCommand=verify exitClass={} elapsedTimeMs={}",
                correlationId, exitClass, elapsedMillis(started));
    }

    private static long elapsedMillis(long started) {
        return Duration.ofNanos(System.nanoTime() - started).toMillis();
    }

    private static WorkspaceProblem unavailable(String message) {
        return new WorkspaceProblem(HttpStatus.SERVICE_UNAVAILABLE, "KERNEL_UNAVAILABLE", message);
    }

    private static void deleteTree(Path directory) {
        if (directory == null) {
            return;
        }
        try (var paths = Files.walk(directory)) {
            paths.sorted(Comparator.reverseOrder()).forEach(path -> {
                try {
                    Files.deleteIfExists(path);
                } catch (IOException ignored) {
                    // A private temporary artifact is never accepted workspace state.
                }
            });
        } catch (IOException ignored) {
            // Best-effort cleanup is retried by the operating system's temporary-file policy.
        }
    }

    public record Verification(String schoolId, String definitionRevision, String timetableRevision) {}
}
