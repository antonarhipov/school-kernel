export const storageKey = 'school-kernel.timetable-demo.v1';
const empty = () => ({ formatVersion: 1, schools: {}, timetables: {}, drafts: {}, selected: null, lastTimetable: {}, editor: null });
const object = value => value !== null && typeof value === 'object' && !Array.isArray(value);
export const draftKey = (school, timetable) => `${school}/${timetable}`;

// A single atomic browser write keeps a new version and removal of its source draft inseparable.
export function createTimetableStorage(storage) {
  let state = empty(), previous = null, writable = true;
  const notices = [];
  try {
    previous = storage.getItem(storageKey);
    if (previous !== null) {
      const value = JSON.parse(previous);
      if (value.formatVersion !== 1 || !['schools', 'timetables', 'drafts', 'lastTimetable'].every(key => object(value[key])))
        throw new Error('Unsupported browser data');
      state = value;
    }
  } catch {
    writable = false;
    notices.push('Saved browser data could not be opened. It has been retained. You can inspect the examples, but changes cannot be saved until browser storage is available.');
  }
  return {
    state: () => structuredClone(state),
    notices,
    write(change, { atomic = false } = {}) {
      const next = structuredClone(state);
      change(next);
      // Keep the working copy on failure so navigation can retain edits even when durable storage is full.
      if (!atomic) state = next;
      if (!writable) throw new Error('Browser storage is unavailable. This change is only in memory and will be lost when this page closes.');
      try {
        if (storage.getItem(storageKey) !== previous)
          throw new Error('Another tab changed this browser’s timetables. Reload before saving; your current edits are still on this page.');
        const serialized = JSON.stringify(next);
        storage.setItem(storageKey, serialized);
        previous = serialized;
        state = next;
      } catch (error) {
        if (error.message.startsWith('Another tab')) throw error;
        throw new Error('Browser storage is full or unavailable. Nothing was saved. Existing saved versions are intact; keep this page open and try again after freeing browser storage.');
      }
    }
  };
}

export function isSchoolDefinition(d) {
  if (!object(d) || typeof d.schoolId !== 'string'
      || !['subjects', 'teachers', 'cohorts', 'rooms', 'periods', 'lessons'].every(key => Array.isArray(d[key])
        && d[key].every(item => object(item) && typeof item.id === 'string')
        && new Set(d[key].map(item => item.id)).size === d[key].length)) return false;
  return d.periods.every(p => typeof p.weekday === 'string' && Number.isInteger(p.order));
}
export function isTimetable(value) {
  const d = value?.definition, a = value?.result?.timetable?.assignments;
  if (typeof value?.id !== 'string' || typeof value?.name !== 'string' || !isSchoolDefinition(d) || !Array.isArray(a)) return false;
  const ids = Object.fromEntries(['subjects', 'teachers', 'cohorts', 'rooms', 'periods', 'lessons']
    .map(key => [key, new Set(d[key].map(item => item.id))]));
  const seen = new Set();
  return a.length === d.lessons.length && a.every(item => {
    if (seen.has(item.lessonId)) return false;
    seen.add(item.lessonId);
    const lesson = d.lessons.find(l => l.id === item.lessonId);
    return ['lessonId', 'subjectId', 'teacherId', 'cohortId', 'roomId', 'periodId'].every((key, i) =>
      typeof item[key] === 'string' && ids[['lessons', 'subjects', 'teachers', 'cohorts', 'rooms', 'periods'][i]].has(item[key]))
      && ['subjectId', 'teacherId', 'cohortId'].every(key => item[key] === lesson[key]);
  });
}
