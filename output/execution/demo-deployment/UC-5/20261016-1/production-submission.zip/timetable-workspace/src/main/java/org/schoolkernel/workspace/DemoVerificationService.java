package org.schoolkernel.workspace;

import java.nio.file.Path;
import java.time.Duration;
import java.util.LinkedHashMap;
import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Profile;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

/** Exact successful verification evidence, bounded independently from immutable packaged samples. */
@Service
@Profile("demo")
class DemoVerificationService {
    private final KernelVerifier verifier;
    private final DemoKernelAllowance allowance;
    private final Semaphore slots = new Semaphore(2, true);
    private final boolean reuse;
    private final long maxBytes, ttlNanos, waitMillis;
    private final Duration timeout;
    private final String build;
    private long residentBytes;
    private final LinkedHashMap<String, Evidence> cache = new LinkedHashMap<>();
    private final java.util.concurrent.ScheduledExecutorService expiry = java.util.concurrent.Executors.newSingleThreadScheduledExecutor(
            Thread.ofVirtual().name("demo-verification-expiry").factory());
    private java.util.concurrent.ScheduledFuture<?> nextExpiry;

    DemoVerificationService(KernelVerifier verifier, DemoKernelAllowance allowance,
            @Value("${demo.reuse.enabled:true}") boolean reuse,
            @Value("${demo.reuse.max-bytes:67108864}") long maxBytes,
            @Value("${demo.reuse.ttl:1h}") Duration ttl,
            @Value("${demo.kernel.verification-wait:10s}") Duration wait,
            @Value("${demo.kernel.verification-timeout:30s}") Duration timeout,
            @Value("${demo.kernel-artifact:kernel-cli/target/school-kernel.jar}") String artifact) throws Exception {
        if (maxBytes < 0 || ttl.isNegative() || ttl.isZero() || ttl.compareTo(Duration.ofHours(1)) > 0
                || wait.isNegative() || wait.compareTo(Duration.ofSeconds(10)) > 0
                || timeout.isNegative() || timeout.isZero() || timeout.compareTo(Duration.ofSeconds(30)) > 0)
            throw new IllegalArgumentException("Invalid demo verification/cache bounds");
        this.verifier = verifier; this.allowance = allowance; this.reuse = reuse; this.maxBytes = maxBytes;
        this.ttlNanos = ttl.toNanos(); this.waitMillis = wait.toMillis(); this.timeout = timeout;
        this.build = DemoSamples.kernelBuild(Path.of(KernelVerifier.resolveExecutable(artifact)));
    }

    KernelVerifier.Verification verify(ImportDocuments documents) {
        // Retain the complete canonical key, not an array-sorting revision or a client hash.
        String key = build + ":" + documents.mode() + ":" + new String(CanonicalJson.bytes(documents.definition()), java.nio.charset.StandardCharsets.UTF_8)
                + ":" + (documents.result() == null ? "absent" : new String(CanonicalJson.bytes(documents.result()), java.nio.charset.StandardCharsets.UTF_8));
        var hit = hit(key);
        if (hit != null) return hit;
        try (var reservation = allowance.reserve(timeout.plusSeconds(4))) {
            boolean acquired;
            try { acquired = slots.tryAcquire(waitMillis, TimeUnit.MILLISECONDS); }
            catch (InterruptedException exception) {
                Thread.currentThread().interrupt();
                throw new WorkspaceProblem(HttpStatus.SERVICE_UNAVAILABLE, "KERNEL_UNAVAILABLE", "Verification was interrupted. The definition was not used.");
            }
            if (!acquired) throw new WorkspaceProblem(HttpStatus.SERVICE_UNAVAILABLE, "VERIFICATION_BUSY",
                    "Verification is busy. The definition was not used. Try again shortly.");
            try {
                hit = hit(key);
                if (hit != null) return hit;
                var verified = verifier.verify(documents, timeout, reservation::started);
                remember(key, verified);
                return verified;
            } finally { slots.release(); }
        }
    }

    private synchronized KernelVerifier.Verification hit(String key) {
        evictExpired();
        Evidence evidence = reuse ? cache.get(key) : null;
        return evidence == null ? null : evidence.verification();
    }
    private synchronized void remember(String key, KernelVerifier.Verification verification) {
        if (!reuse) return;
        evictExpired();
        long bytes = 2L * key.length() + 2L * (verification.schoolId().length() + verification.definitionRevision().length()
                + (verification.timetableRevision() == null ? 0 : verification.timetableRevision().length())) + 512;
        if (bytes > maxBytes) return;
        Evidence old = cache.remove(key);
        if (old != null) residentBytes -= old.bytes();
        while (residentBytes + bytes > maxBytes && !cache.isEmpty()) {
            var first = cache.entrySet().iterator(); residentBytes -= first.next().getValue().bytes(); first.remove();
        }
        cache.put(key, new Evidence(verification, System.nanoTime(), bytes)); residentBytes += bytes;
        scheduleExpiry();
    }
    private void evictExpired() {
        long now = System.nanoTime();
        cache.values().removeIf(evidence -> {
            if (now - evidence.completed() < ttlNanos) return false;
            residentBytes -= evidence.bytes(); return true;
        });
    }
    private synchronized void scheduleExpiry() {
        if (nextExpiry != null) nextExpiry.cancel(false);
        if (cache.isEmpty()) { nextExpiry = null; return; }
        long first = cache.values().iterator().next().completed();
        nextExpiry = expiry.schedule(() -> {
            synchronized (this) { evictExpired(); scheduleExpiry(); }
        }, Math.max(1, ttlNanos - (System.nanoTime() - first)), TimeUnit.NANOSECONDS);
    }
    @jakarta.annotation.PreDestroy synchronized void close() {
        expiry.shutdownNow(); cache.clear(); residentBytes = 0;
    }
    private record Evidence(KernelVerifier.Verification verification, long completed, long bytes) {}
}
