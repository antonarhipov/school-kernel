package org.schoolkernel.workspace;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import java.io.IOException;
import java.time.Duration;
import java.util.*;
import org.junit.jupiter.api.*;
import org.springframework.beans.factory.support.StaticListableBeanFactory;
import org.springframework.mock.web.MockHttpSession;
import tools.jackson.databind.JsonNode;
import tools.jackson.databind.json.JsonMapper;
import tools.jackson.databind.node.ObjectNode;

/** Lifecycle/refusal and immutable-copy checks; real process and scoring checks live at the packaged boundary. */
class DemoSamplesTest {
    private final JsonMapper json = JsonMapper.builder().build();
    private DemoWorkspaces owners;
    private DemoWorkspaceStore store;
    private KernelVerifier verifier;
    private DemoSamples samples;
    private final String artifact = "../kernel-cli/target/school-kernel.jar";

    @BeforeEach void setup() throws Exception {
        var beans = new StaticListableBeanFactory();
        owners = new DemoWorkspaces(new DemoSettings(List.of("demo.example"), List.of(), false,
                Duration.ofHours(1), Duration.ofHours(8), 50), json, beans.getBeanProvider(KernelPlanner.class));
        store = new DemoWorkspaceStore(owners);
        verifier = mock(KernelVerifier.class);
        when(verifier.verify(any())).thenAnswer(call -> {
            ImportDocuments docs = call.getArgument(0);
            return new KernelVerifier.Verification(docs.definition().path("schoolId").asString(),
                    docs.result().path("inputRevision").asString(), docs.result().path("timetableRevision").asString());
        });
        samples = sampleService(new WorkspaceMutation(store));
        samples.verifyPackagedSamples();
    }
    @AfterEach void close() { owners.close(); }
    private DemoSamples sampleService(WorkspaceMutation mutation) {
        return new DemoSamples(json, verifier, new ManifestService(), store, mutation, artifact);
    }
    private JsonNode read(String name) { try { return samples.read(name); } catch (IOException e) { throw new RuntimeException(e); } }
    @Test void exactCatalogCopiesPreviewAndThreeOpensNeverInvokeVisitorVerification() {
        var catalog = samples.catalog();
        assertEquals(List.of("small", "two-class", "full"), java.util.stream.StreamSupport.stream(catalog.spliterator(), false)
                .map(row -> row.path("identifier").asString()).toList());
        var owner = owners.open(new MockHttpSession(), true);
        owners.bound(owner, () -> {
            for (String id : List.of("small", "two-class", "full")) {
                JsonNode original = samples.preview(id).path("definition").deepCopy();
                ObjectNode preview = samples.preview(id); ((ObjectNode) preview.path("definition")).put("displayName", "Edited privately");
                assertEquals(original, samples.preview(id).path("definition"));
                var current = store.load();
                var opened = samples.use(id, current.etag(), current.state() != WorkspaceState.EMPTY);
                assertEquals(WorkspaceState.ACCEPTED_BASELINE, opened.state());
                assertEquals(original, opened.document().path("acceptedBaseline").path("definition"));
                assertEquals(read(id + "-result.json"), opened.document().path("acceptedBaseline").path("result"));
                ((ObjectNode) opened.document().path("acceptedBaseline").path("definition")).put("displayName", "Caller mutation");
                assertEquals(original, store.load().document().path("acceptedBaseline").path("definition"));
            }
        });
        verify(verifier, times(3)).verify(any()); // deployment only, independent of any visitor cache/admission state
    }
    @Test void declineUnknownStaleAndActiveRunPreserveCompleteWorkInEveryLifecycle() {
        var owner = owners.open(new MockHttpSession(), true);
        owners.bound(owner, () -> {
            samples.use("small", store.load().etag(), false);
            for (var state : WorkspaceState.values()) {
                if (state == WorkspaceState.EMPTY || state == WorkspaceState.DEFINITION_DRAFT) continue;
                var before = store.load();
                var document = before.document().deepCopy();
                ((ObjectNode) document).putObject("privateDraft").put("exact", state.name());
                store.replace(before.version(), before.state(), state, document);
                var prior = store.load();
                assertEquals("SAMPLE_NOT_FOUND", assertThrows(WorkspaceProblem.class,
                        () -> samples.use("unknown", prior.etag(), true)).code());
                assertEquals(prior, store.load());
                assertEquals("STALE_WORKSPACE_VERSION", assertThrows(WorkspaceProblem.class,
                        () -> samples.use("full", "\"ws-0\"", true)).code());
                assertEquals(prior, store.load());
                boolean active = state == WorkspaceState.SOLVING_INITIAL || state == WorkspaceState.SOLVING_REPAIR;
                assertEquals(active ? "INVALID_WORKSPACE_TRANSITION" : "REPLACEMENT_CONFIRMATION_REQUIRED",
                        assertThrows(WorkspaceProblem.class, () -> samples.use("full", prior.etag(), false)).code());
                assertEquals(prior, store.load());
                if (active) {
                    assertEquals("INVALID_WORKSPACE_TRANSITION", assertThrows(WorkspaceProblem.class,
                            () -> samples.use("full", prior.etag(), true)).code());
                    assertEquals(prior, store.load());
                    store.replace(prior.version(), prior.state(), WorkspaceState.ACCEPTED_BASELINE, prior.document());
                } else assertEquals(WorkspaceState.ACCEPTED_BASELINE, samples.use("full", prior.etag(), true).state());
            }
        });
        verify(verifier, times(3)).verify(any());
    }
    @Test void installationFailureRetainsCurrentAndOtherOwnerIsIndependent() {
        var first = owners.open(new MockHttpSession(), true); var second = owners.open(new MockHttpSession(), true);
        owners.bound(first, () -> samples.use("small", store.load().etag(), false));
        owners.bound(second, () -> samples.use("full", store.load().etag(), false));
        var failingMutation = mock(WorkspaceMutation.class);
        when(failingMutation.resetAndImport(anyLong(), any(), any())).thenThrow(new IllegalStateException("save unavailable"));
        DemoSamples failing = sampleService(failingMutation);
        assertDoesNotThrow(failing::verifyPackagedSamples);
        owners.bound(first, () -> {
            var prior = store.load();
            assertThrows(IllegalStateException.class, () -> failing.use("two-class", prior.etag(), true));
            assertEquals(prior, store.load());
            samples.use("two-class", prior.etag(), true);
        });
        owners.bound(second, () -> assertEquals("full", store.load().document().path("origin").asString()));
    }
    @Test void buildScoreDefinitionResultAndCatalogMismatchFailReadinessBeforePublishingSamples() throws Exception {
        for (String field : List.of("build", "score", "definition", "result", "catalog")) {
            DemoSamples corrupt = new DemoSamples(json, verifier, new ManifestService(), store, new WorkspaceMutation(store), artifact) {
                @Override JsonNode read(String name) throws IOException {
                    ObjectNode node = (ObjectNode) super.read(name);
                    if (field.equals("build") && name.equals("scoring-evidence.json")) node.put("kernelBuild", "old-build");
                    if (field.equals("score") && name.equals("scoring-evidence.json"))
                        ((ObjectNode) node.path("samples").path("full").path("score")).put("ordinaryPreferencePenalty", -1);
                    if (field.equals("definition") && name.equals("full-definition.json")) node.put("displayName", "tampered");
                    if (field.equals("result") && name.equals("full-result.json")) node.put("elapsedTimeMs", -1);
                    if (field.equals("catalog") && name.equals("scoring-evidence.json")) node.put("catalogVersion", -1);
                    return node;
                }
            };
            assertThrows(IllegalStateException.class, corrupt::verifyPackagedSamples, field);
            assertTrue(corrupt.catalog().isEmpty(), "No partially validated catalog: " + field);
        }
    }
    @Test void missingOrNonBooleanConfirmationIsASafeRefusalAtControllerBoundary() {
        var owner = owners.open(new MockHttpSession(), true);
        owners.bound(owner, () -> {
            samples.use("small", store.load().etag(), false);
            var prior = store.load(); var controller = new DemoSampleController(samples, mock(WorkspaceController.class));
            for (String text : List.of("{}", "{\"confirmed\":\"true\"}", "{\"confirmed\":1}", "[]", "null")) {
                assertEquals("REPLACEMENT_CONFIRMATION_REQUIRED", assertThrows(WorkspaceProblem.class,
                        () -> controller.use("full", prior.etag(), json.readTree(text))).code());
                assertEquals(prior, store.load());
            }
            assertEquals("REPLACEMENT_CONFIRMATION_REQUIRED", assertThrows(WorkspaceProblem.class,
                    () -> controller.use("full", prior.etag(), null)).code());
            assertEquals(prior, store.load());
        });
    }
    @Test void realVerificationFailurePreventsSamplePublication() {
        doThrow(new WorkspaceProblem(org.springframework.http.HttpStatus.UNPROCESSABLE_ENTITY,
                "KERNEL_VERIFICATION_FAILED", "Invalid pair")).when(verifier).verify(any());
        var invalid = sampleService(new WorkspaceMutation(store));
        assertThrows(WorkspaceProblem.class, invalid::verifyPackagedSamples);
        assertTrue(invalid.catalog().isEmpty());
    }
}
