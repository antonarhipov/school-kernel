# Demo container preparation

This is a locally testable deployment artifact, not a qualified public release. Read
[execution status](../../spec/demo-deployment/status.md) before deploying. UC-2's public private-session, restart and
expiry checks pass under the audited isolated-ingress boundary described below. Visitor queueing, reservations, reuse, complete custom-definition flows and operational events remain
unimplemented/unqualified in their later use cases. Do not publish this intermediate build to visitors.

Build from the repository root:

```sh
docker build --file deploy/demo/Dockerfile --tag school-kernel-demo:local .
```

The build context explicitly includes only production inputs. It excludes real-school examples, tests, operator
configuration, Git metadata and prior build output. The runtime image contains the workspace JAR, packaged kernel
and two launchers. It runs as UID/GID 10001, with a private umask and no database/volume. The demo profile binds to
`0.0.0.0:$PORT` (8080 by default). All three packaged samples must pass code/document fingerprint checks and real
kernel verification before the HTTP server becomes ready. A scoring-evidence mismatch intentionally fails startup;
never regenerate that evidence merely to bypass the failure. Regenerate/verify the sample results through the
explicit maintenance workflow when kernel scoring/build inputs change.

Starting JVM heap ceilings are 512 MiB for the web process, 1,024 MiB for a solve and 256 MiB for each verification.
`DEMO_WEB_HEAP_MB`, `DEMO_SOLVER_HEAP_MB` and `DEMO_VERIFY_HEAP_MB` can override them with positive integers.
These are tuning inputs, not an aggregate memory qualification; native memory, caches, workspaces and concurrent
verification must be measured under UC-12. The image's Java process is PID 1 and receives SIGTERM directly.

For a health-only local smoke check, use an isolated container (never a local school database):

```sh
docker run --rm --name school-kernel-demo-smoke --read-only \
  --tmpfs /tmp:rw,noexec,nosuid,size=128m --cpus 2 --memory 3000000000 \
  --publish 127.0.0.1:18080:8080 --env DEMO_PUBLIC_HOSTS=demo.example \
  school-kernel-demo:local
```

In another terminal, `curl -H 'Host: healthcheck.railway.app' http://127.0.0.1:18080/healthz` must return `UP`
without a session cookie. Normal visitor requests require HTTPS and a configured host, so this HTTP smoke check
does not exercise the browser or prove an edge trust boundary. Stop the disposable container after the check.

The legacy `deploy/demo/railway.json` describes the original qualification settings. The file
sets one replica, sleeping off, `/healthz` readiness, 2 vCPU/3 GB starting limits and shutdown timing. Its field names
were checked against [Railway's live schema](https://railway.com/railway.schema.json) on 2026-10-16. It intentionally
does not invent an operator account, region, domain, proxy network or financial control. The live API now rejects
new legacy config-file assignments and recommends `.railway/railway.ts`; migrate these qualification settings before
launch. Merely passing the legacy JSON schema does not prove the current deployment API accepts the file.

The operator must supply the Hobby project/service/environment and generated domain, select one EU region, and
set `DEMO_PUBLIC_HOSTS` to the exact lowercase generated domain authority. Railway does not publish a stable
proxy-peer address range. Use `DEMO_RAILWAY_ISOLATED_INGRESS=true` only for an isolated project/environment that
contains exactly this service, one replica and no TCP proxy. First retain a passing read-only preflight:

```sh
python3 tools/demo/check_railway_boundary.py --project <project-id> --environment <environment-id> \
  --service <service-id> --domain <generated-domain> --output <evidence.json>
```

This option also requires Railway's project/environment/service identities and an exact `RAILWAY_PUBLIC_DOMAIN`
match at startup. Leave `DEMO_TRUSTED_PROXY_ADDRESSES` empty. The HTTP edge overwrites scheme/host forwarding,
but a private service or raw TCP caller can forge it; the isolated topology is therefore a required trust boundary.
Recheck before every deployment and after restart; adding a service, domain or TCP proxy requires requalification.
See [RULE-1](../../spec/demo-deployment/rules.md) and its provider sources. There is no per-request cryptographic
edge identity. Only an operator-controlled stable proxy uses the alternative `DEMO_TRUSTED_PROXY_ADDRESSES`
allowlist. Both options default off/empty. Never guess a Railway subnet or trust all private networks.
`Forwarded` is refused. A single `X-Forwarded-Host` may only match the independently allowlisted native `Host`;
it never supplies authority. Duplicate/mismatched forwarding and foreign Origin remain refused.
Only GET `/healthz` accepts `healthcheck.railway.app`.

Configure and record the workspace-wide $5 spending alert and $15 hard limit, including effects on other workloads.
The repository file cannot establish those account settings. No provider token belongs in the repository or browser.
An isolated Free smoke service has been deployed; it is not the qualified public demo. See the execution status.

## Isolated Free-plan smoke test

`railway-free-smoke.ts` records the separate test service's effective settings: one EU replica, one CPU and
500,000,000 bytes of memory. Free requires `sleepApplication=true`; it cannot qualify the always-on specification.
Keep the full qualification configuration in `railway.json`. For this initial test, set `DEMO_WEB_HEAP_MB=128`,
`DEMO_VERIFY_HEAP_MB=96` and `DEMO_SOLVER_HEAP_MB=128`; restrict the workspace count to two using
`SPRING_APPLICATION_JSON={"demo":{"max-workspaces":2}}`. The first test covers startup, packaged samples,
HTTPS and session isolation. It does not qualify solving or the full visitor workload. No account upgrade is required
to attempt it. The first deployed test passed startup, packaged sample checks and a real two-owner HTTPS Chrome
journey, but restarting the service exposed intermittent 403s with the empirical exact-peer proxy allowlist.
The [UC-2 resumption](../../spec/demo-deployment/checkpoints/UC-2.md) replaced that list with the explicit isolated-ingress
mode after the provider topology check. The complete public ownership, two-restart and idle/absolute-expiry journeys
pass, followed by restoration of 60-minute idle / 8-hour absolute expiry and the two-workspace smoke cap.
Keep the isolation preflight and configuration constraints above; this passing session boundary does not qualify launch.
The [first test ledger](../../output/execution/demo-deployment/UC-12/railway-free-20261016-3/ledger.md) retains the original failure.
No solve capacity is established. This exported IaC file requires the Railway
TypeScript SDK for plan/apply; it is a snapshot of settings actually applied through the service API, not evidence
of a successful IaC plan/apply.

The matching local preflight is:

```sh
python3 tools/demo/smoke_container.py --memory-bytes 512000000 --cpus 1 --web-heap-mb 128 --verify-heap-mb 96
```

Use an explicitly staged production-only directory for CLI upload. Configure the isolated service before uploading;
the actual smoke upload has no legacy `railway.json`. `.dockerignore` restricts image inputs but does not by itself guarantee the CLI upload excludes
operator files, source examples or prior evidence. Keep a hash manifest of the staged upload outside that directory.
Authenticate the local CLI through `railway login --browserless`; the operator authorizes it in their own signed-in
browser. Credentials, tokens and the transient pairing code do not belong in the upload or evidence.

Before public launch, complete every remaining UC and record the deployed qualification required by
[UC-12](../../spec/demo-deployment/spec.md#uc-12---launch-a-demo-with-measured-capacity-and-spend-protection): cold
reuse-disabled target-school solves, actual process/reservation bounds, aggregate memory at the workspace/cache
ceiling with one solve and two verifiers, public two-browser lifecycle journeys, expiry/redeploy, edge spoof checks,
safe logs, and spend/resource controls. Keep the spec's intended larger-school target if initial settings fail.

## Maintaining the three samples

Ordinary builds package the committed fictional documents; they never read `examples/` or run sample generation.
To deliberately regenerate definitions, run `python3 tools/demo/generate_samples.py`, regenerate all three results
using the current packaged kernel (Quick for Small/Two-class; Thorough for Full), then run
`python3 tools/demo/record_scoring_evidence.py`. This last command evaluates every stored assignment with that
kernel, compares the complete score breakdown, weights and revisions, and refuses stale scoring. It does not bless
an old result by merely updating hashes. Commit the resulting complete pairs and generation/scoring evidence together.

Before packaging, `python3 tools/demo/generate_samples.py --check` reproduces inverse-map fidelity and ordering
without changing any source/sample. `tools/demo/check_packaged_samples.py --output <evidence.json> <kernel.jar>
<workspace.jar>` scans the actual JARs (including nested dependencies) for source identities and excluded examples,
and checks the committed distinct demo-name pool and reference mapping. `tools/demo/check_sample_readiness.py
--output <directory>` checks startup refusal using disposable corrupt JAR copies. These maintenance tools are
excluded from the production image and upload context. UC-3's checkpoint records the public sample walkthrough;
repair execution, manual publication and full bundle round-trip remain owned by their later UCs.
