# Demo deployment execution

Base: `d55ab636558224f2d33a5e71313e840dd9486428` (`demo`).
Pre-existing changes: `spec/README.md` modified; `spec/demo-deployment/proposal.md` and `spec.md` untracked.
These specification inputs are preserved. No commit has been requested. The operator has authorized an isolated
Railway Free-plan deployment attempt; this does not authorize a plan upgrade or qualify public launch.

| UC | Status | Requires |
|---|---|---|
| UC-1 | APPROVED | None |
| UC-2 | APPROVED | None |
| UC-3 | APPROVED | UC-2 |
| UC-4 | NOT_STARTED | UC-2 |
| UC-5 | NOT_STARTED | UC-4 |
| UC-6 | NOT_STARTED | UC-2 |
| UC-7 | NOT_STARTED | UC-2 |
| UC-8 | NOT_STARTED | UC-6 |
| UC-9 | NOT_STARTED | UC-2 |
| UC-10 | NOT_STARTED | UC-2 |
| UC-11 | NOT_STARTED | UC-2 |
| UC-12 | BLOCKED | None |
| UC-13 | NOT_STARTED | UC-12 |

## Evidence

- 2026-10-16: Read the complete specification and execute workflow. Relationship targets exist and the explicit
  dependency graph is acyclic. UC-1 is the first eligible slice. Its packaged CLI boundary requires no browser.
- Deployment qualification (UC-12/13) requires the operator's Railway Hobby service and spending configuration.
  Local checks will not be represented as deployed capacity or public-launch approval.
- 2026-10-16: UC-1 approved from the [packaged execution ledger](../../output/execution/demo-deployment/UC-1/20261016-2/ledger.md)
  and [checkpoint](checkpoints/UC-1.md). Next: UC-2. Storage abstraction and explicit owner propagation are enabling
  work for its session boundary; the local PostgreSQL implementation remains the non-demo profile.
- 2026-10-16: UC-2 implementation passed the full **local** packaged TLS/two-browser journey and 39 workspace unit
  tests. See its [checkpoint](checkpoints/UC-2.md), [technical ledger](../../output/execution/demo-deployment/UC-2/20261016-final/ledger.md)
  and [passing browser ledger](../../output/playwright/demo-deployment/UC-2/1792140998412/ledger.md).
  Browser findings (draft-state export, narrow JSON editing and ended-session CSRF/authoring guard) were fixed;
  failed attempts are retained. The normal-profile HTTP regression has 23 passes and two failures reproduced on
  unchanged base `d55ab636`; they are not introduced regressions.
- **Historical blocker, resolved by the UC-2 approval below:** The isolated Free deployment passed startup, sample verification and a real public
  two-owner Chrome smoke. The subsequent operator restart exposed intermittent public health 403s (13/15 requests
  200, 2/15 refused) despite provider SUCCESS. The empirically observed exact proxy-peer allowlist is insufficient
  for reliable access across restart. A stable, justified provider trust boundary and repeated restart/browser
  evidence remain required. SSH gateway trust was explicitly approved by the operator; its temporary access key
  has been revoked and local key files removed. UC-2 and UC-12 remain unapproved; dependent UCs have not advanced.
- 2026-10-16: Independently eligible UC-12 has concrete [container/configuration preparation](../../deploy/demo/README.md)
  and a [checkpoint](checkpoints/UC-12.md). The pinned non-root image builds from a production-only context; its
  read-only-container [smoke ledger](../../output/execution/demo-deployment/UC-12/1792141341654519000/ledger.md)
  records all three real startup verifications, safe HTTP/header refusal, direct SIGTERM and cleanup. The artifact
  scan found zero source school/teacher name matches in 53 packaged text resources. Railway configuration fields
  match the live schema checked on this date. No deployment, financial change or capacity qualification occurred.
  UC-12 is BLOCKED on the same unavailable Railway boundary and its later-use-case launch prerequisites.
- Enabling work does not approve UC-3/4/10: three fictional sample pairs and local JSON save/download are present;
  custom stored-version use is disabled pending UC-5. UC-6's bounded queue, reuse/coalescing, daily reservations and
  visitor verification limits are not yet implemented. UC-7/8/9/11/13 still need their full feature-specific
  implementation and journeys. Do not expose this intermediate build as the public demo.
- 2026-10-16: The operator authorized a first Free-plan smoke test. A separate
  [smoke configuration](../../deploy/demo/railway-free-smoke.ts) preserves the 2-vCPU/3-GB qualification configuration.
  The [512-MB/one-CPU local preflight](../../output/execution/demo-deployment/UC-12/1792147970154196000/ledger.md)
  passed startup, three real packaged sample verifications, health/security refusal and shutdown with 128-MiB web /
  96-MiB verifier heaps. Idle memory observed after startup was 213.6 MiB; startup peak and deployed capacity are not
  established. A production-only CLI upload context has 150 files (1,681,314 bytes), with its hash manifest retained
  beside that ledger. No deployment or billing change occurred; browserless CLI authorization is pending.
- 2026-10-16, subsequent deployed attempt: CLI authorization succeeded. Created only `school-kernel-free-smoke` /
  `demo-smoke`; existing unrelated project preserved. Deployment `a8ceaa5c-4141-4835-bcab-58f4cfc7d4ce` is SUCCESS
  in `europe-west4-drams3a`, one CPU / 500,000,000 bytes / one replica, sleeping enabled as Free requires.
  All three packaged samples verified; startup completed in 8.067 s. Recorded platform memory samples reached
  0.202960896 GB and settled around 0.1688 GB; this is not continuous peak or solver capacity qualification.
  The actual upload had 149 production-only files (1,680,788 bytes); no legacy config, tests, examples, operator data
  or credentials were uploaded. See [deployed evidence](../../output/execution/demo-deployment/UC-12/railway-free-20261016-1/ledger.md).
  The API rejects new legacy config-file assignments, and Free requires sleeping. Effective settings were applied
  through supported service APIs and exported as IaC; SDK absence prevented IaC plan execution. No IaC apply, plan
  upgrade or billing mutation occurred. UC-12 remains unqualified; the full specification retains Hobby/always-on.

- 2026-10-16, first Free-test conclusion: [fixed-image/restart ledger](../../output/execution/demo-deployment/UC-12/railway-free-20261016-3/ledger.md)
  records the trusted matching X-Forwarded-Host fix, 8 focused passing tests, 29/29 modules available, real
  [two-owner Chrome smoke PASS](../../output/playwright/demo-deployment/free-smoke/20261016-5/ledger.md), and the
  post-restart public-access failure. Startup verifies all three exact fictional sample pairs. Cgroup peak during
  startup/sample smoke was 207,659,008 bytes; this proves no solve/full-load capacity. No plan or billing change
  occurred. Earlier CLI/SSH approval blockers are resolved. The isolated service remains sleeping-enabled and
  intermittently refuses access; do not represent the passing pre-restart browser journey as reliable deployment
  qualification. Temporary SSH access and disposable browser/workspace state have been cleaned up.

- 2026-10-16, UC-2 resumed on the same base/dirty checkout at the user's request. The previous failed restart
  evidence is retained. Railway's [staff-confirmed boundary](https://station.railway.com/questions/fastapi-uvicorn-trusted-proxy-configura-9c06fa12)
  explicitly provides no stable proxy CIDR. Use an opt-in isolated project/environment with exactly one service and
  no TCP proxy, after read-only provider preflight; never widen the empirical address list. See [technical rules](rules.md).
  Current provider inspection shows one service/replica and zero TCP proxies. Public lifecycle/restarts remain to run.

- UC-2 resumed technical checks PASS: 46 workspace unit tests in 12 classes plus the complete packaged local TLS
  browser journey. New deployment `99089c8b-928e-4a53-93a7-f7a414339bd1` is SUCCESS; 149 production-only inputs
  were uploaded. Isolated ingress is explicit, default-off and bound to Railway identity/generated domain.
  Public lifecycle, repeated provider restart, spoof and expiry walkthroughs are running before approval.

- Resumed public UC-2 journey PASS on [attempt 3](../../output/playwright/demo-deployment/UC-2/public-20261016-3/ledger.md):
  two independent owners plus a stale shared-owner tab, exact export/import, private draft/run/cancellation,
  declined/active/stale refusals, capacity UI, two real provider restarts and 40 consecutive health/static checks
  after each. [Recovery/privacy diagnostic](../../output/playwright/demo-deployment/UC-2/ended-diagnostic-20261016-2/ledger.md)
  also passed 20 browser/API reads, reload, complete disclosures/headers and stale-clear non-mutation.
  Earlier public attempts failed because the harness sampled asynchronous session rotation before completion;
  explicit awaited state polling fixed the harness, with no application session change. Failed evidence is retained.
  The 73 stateless public edge/spoof probes passed. Short-clock deployed expiry and exact default restoration remain.

- 2026-10-16, UC-2 **APPROVED**. The [resumed execution ledger](../../output/execution/demo-deployment/UC-2/20261016-resume-1/ledger.md)
  and [final checkpoint](checkpoints/UC-2.md) bind the deployed production inputs and exact four-file ingress fix.
  The public two-owner/repeated-restart walkthrough, recovery/privacy/stale-clear supplement and
  [deployed idle/absolute expiry walkthrough](../../output/playwright/demo-deployment/UC-2/public-expiry-20261016-3/ledger.md)
  all pass. Polling extends idle activity but does not defeat absolute expiry; no work is recovered or auto-accepted.
  Normal 60-minute/8-hour settings and the two-workspace smoke cap were restored on deployment
  `1fc1827a-71d6-4d12-8c18-9e20545fd22a` (same image). Final topology/config checks and another 73 stateless
  edge/security probes pass. The final packaged local browser regression passes; 46 workspace unit tests pass.
  The earlier proxy-peer failure is superseded by RULE-1's explicit, audited isolated-ingress mode, not erased.
  Scope ends at UC-2: later visitor UCs are unchanged; UC-12 remains BLOCKED on Hobby/always-on, measured capacity,
  spending controls and later-use-case launch prerequisites. No commit or financial setting change was made.

- 2026-10-16: UC-3 started on base `d55ab636` with approved UC-2. The [starting manifest](../../output/execution/demo-deployment/UC-3/20261016-1/start-source-manifest.json) and status/diff beside it preserve the pre-existing dirty boundary. Scope is bundled sample preview/use, replacement safety, artifact/scoring/anonymization checks, and public inspection/repair/export entry points. Later destination workflows retain their own approval gates.

- UC-3 walkthrough attempt `local-20261016-3` found a missing-confirmation request returning 500 (Jackson strict boolean access); exact Current/draft non-mutation passed. Status `NEEDS_REVISION` until fixed and re-walked. The controller now requires an actual JSON boolean before reading it. The failed ledger/screenshots are retained.

- UC-3 technical/local-browser checks PASS after the confirmation fix: 52 workspace and 107 kernel unit tests;
  exact inverse/order reproduction; score recomputation; artifact/image exclusion scans; real corrupt-package startup
  refusals; read-only container smoke; full [local sample walkthrough](../../output/playwright/demo-deployment/UC-3/local-20261016-6/ledger.md)
  and affected [UC-2 session regression](../../output/playwright/demo-deployment/UC-2/uc3-regression-20261016-1/ledger.md).
  The inline manual editor starts a draft on the first period/room change; attempt 5's obsolete button locator was
  corrected without changing production. Public HTTPS walkthrough is pending on the exact seven-file production delta.

- 2026-10-16: UC-3 **APPROVED**. The [checkpoint](checkpoints/UC-3.md) and
  [execution ledger](../../output/execution/demo-deployment/UC-3/20261016-1/ledger.md) bind the exact dirty submission,
  seven-file production delta and 149-file upload. [Public Chrome walkthrough](../../output/playwright/demo-deployment/UC-3/public-20261016-1/ledger.md)
  PASS on deployment `ef120a58-f97c-4ed1-b03d-f71a4d662eef`: all three exact sample pairs open without a visitor kernel
  process; Full Week/Day/lenses/details/narrow inspection, repair staging, accepted export and inline manual entry pass.
  Unsaved/declined/stale/unknown/unconfirmed/failing replacements preserve complete Current/drafts and the second owner.
  Real missing-confirmation 500 was fixed to safe 428; failed attempts are retained. All 159 unit tests pass; the affected
  UC-2 packaged session regression, artifact/scoring/anonymization/readiness/container checks and 73 deployed edge
  probes pass. Deployed logs show exactly three startup verifications, six sample opens and zero visitor computation.
  Public screenshots were visually inspected. A cleanup restart removes both disposable sessions, re-verifies all three
  pairs and passes 40 consecutive session-free health/static reads; the final isolated-ingress preflight passes.
  No later UC was started or approved, no commit was made, and no financial/provider configuration was changed.
  UC-6 must preserve sample independence when cache/allowance components are introduced; their lifecycle states are
  not claimed as live coverage here. UC-12's launch/capacity/spending blockers remain unchanged.

- Final UC-3 hash audit: a concurrent text-only Delete all browser-storage label/tooltip/confirmation edit was found
  in `demo-panel.js` after the approved upload. It is preserved and captured separately in the execution directory;
  the approval/deployment ZIP uses the exact staged production bytes. All other 148 uploaded production files still
  match the checkout. This separate copy edit is outside UC-3 and is not represented as part of its browser evidence.
