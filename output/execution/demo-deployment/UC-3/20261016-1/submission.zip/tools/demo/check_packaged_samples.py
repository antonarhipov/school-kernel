#!/usr/bin/env python3
"""Check fictional sample provenance and shipped JARs without emitting source identities."""
import argparse
import hashlib
import io
import json
import subprocess
import struct
import sys
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--output', required=True, type=Path)
parser.add_argument('jars', nargs='+', type=Path)
args = parser.parse_args()
subprocess.run(['python3', str(Path(__file__).with_name('generate_samples.py')), '--check'], check=True)
sys.dont_write_bytecode = True
from generate_samples import SAMPLES, COLLECTIONS, FIELDS, strings
names = json.loads(Path(__file__).with_name('names.json').read_text())
assert len(names) == len(set(names)) >= 51
source_names = set()
for identifier, filename, title in SAMPLES:
    source = json.loads((ROOT / f'examples/{filename}.json').read_text())
    sample = json.loads((ROOT / f'timetable-workspace/src/main/resources/demo/samples/{identifier}-definition.json').read_text())
    source_names.add(source['displayName'])
    source_names.update(t['displayName'] for t in source['teachers'])
    assert sample['displayName'] == title
    teachers = [t['displayName'] for t in sample['teachers']]
    assert len(teachers) == len(set(teachers)) and set(teachers) <= set(names)
    for collection, kind in COLLECTIONS.items():
        source_ids = {row['id'] for row in source.get(collection, [])}
        assert source_ids.isdisjoint(row['id'] for row in sample.get(collection, [])), identifier
    for field in FIELDS:
        assert set(strings(source, field)).isdisjoint(strings(sample, field)), identifier

checked = []
def scan(data, path):
    with zipfile.ZipFile(io.BytesIO(data)) as archive:
        for entry in archive.infolist():
            if entry.is_dir(): continue
            assert not entry.filename.startswith('examples/'), 'Real examples packaged'
            body = archive.read(entry)
            if entry.filename.endswith('.jar'):
                scan(body, path + '!' + entry.filename)
            else:
                # Exact string literals cover every source name; full multiword names are also scanned as raw bytes.
                # A generic single-word substring in third-party author metadata is not a source identity.
                for name in source_names:
                    for literal in ({json.dumps(name, ensure_ascii=False), json.dumps(name, ensure_ascii=True)} | ({name} if ' ' in name else set())):
                        assert literal.encode() not in body, 'Source identity found in shipped artifact'
                    encoded = name.encode()
                    if entry.filename.endswith('.class'):
                        assert b'\x01' + struct.pack('>H', len(encoded)) + encoded not in body, 'Source identity in JVM string constant'
                checked.append(path + '!' + entry.filename)

artifacts = {}
for jar in args.jars:
    data = jar.read_bytes(); scan(data, str(jar))
    artifacts[str(jar)] = hashlib.sha256(data).hexdigest()
args.output.parent.mkdir(parents=True, exist_ok=True)
args.output.write_text(json.dumps({'verdict': 'PASS', 'artifacts': artifacts, 'scannedEntries': len(checked),
    'sourceIdentityCount': len(source_names), 'namesPoolDistinct': len(names),
    'inverseAndOrdering': 'exact for all three', 'sourceIdentityMatches': 0,
    'sourceReferenceOverlap': 0, 'packagedExamples': 0}, indent=2) + '\n')
print('PASS: sample provenance, distinct demo-name pool, source reference exclusion and', len(checked), 'packaged entries')
