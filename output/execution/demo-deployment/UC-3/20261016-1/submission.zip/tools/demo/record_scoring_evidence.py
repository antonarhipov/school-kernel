#!/usr/bin/env python3
"""Record a freshly generated sample's exact result and kernel code/schema identity.

Run only after regenerating all results with the current packaged kernel. Startup still verifies every pair.
"""
import hashlib
import json
import zipfile
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
SAMPLES = ROOT / "timetable-workspace/src/main/resources/demo/samples"
with zipfile.ZipFile(ROOT / "kernel-cli/target/school-kernel.jar") as archive:
    digest = hashlib.sha256()
    for name in sorted(name for name in archive.namelist()
                       if name.startswith("org/schoolkernel/") and name.endswith(".class")
                       or name.startswith("schema/") and name.endswith(".json")):
        digest.update(name.encode() + b"\0" + archive.read(name))
build = digest.hexdigest()
checked = json.loads(subprocess.check_output([
    "java", "--class-path", str(ROOT / "kernel-cli/target/school-kernel.jar"),
    str(Path(__file__).with_name("VerifySampleScores.java")), str(SAMPLES)], text=True))
evidence = {"kernelBuild": build, "catalogVersion": checked["catalogVersion"], "samples": {}}
for identifier in ("small", "two-class", "full"):
    pair = {}
    for kind in ("definition", "result"):
        document = json.loads((SAMPLES / f"{identifier}-{kind}.json").read_text())
        if kind == "result":
            assert document["status"] == "FEASIBLE"
        canonical = json.dumps(document, sort_keys=True, ensure_ascii=False, separators=(",", ":")).encode()
        pair[kind + "Sha256"] = hashlib.sha256(canonical).hexdigest()
    pair["score"] = checked["samples"][identifier]
    evidence["samples"][identifier] = pair
(SAMPLES / "scoring-evidence.json").write_text(json.dumps(evidence, indent=2) + "\n")
